/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.dao;

/**
 *
 * @author Harikrishna
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.model.Applicant;
import com.example.util.DBConnectionUtil;

public class ApplicantDAOImpl implements ApplicantDAO {

    @Override
    public boolean applyJob(Applicant applicant) {
        try (Connection connection = DBConnectionUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO applicants (job_id, student_id) VALUES (?, ?)")) {
            preparedStatement.setInt(1, applicant.getJobId());
            preparedStatement.setInt(2, applicant.getStudentId());
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Applicant> getAllApplicantsForJob(int jobId) {
        List<Applicant> applicants = new ArrayList<>();
        try (Connection connection = DBConnectionUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT * FROM applicants WHERE job_id = ?")) {
            preparedStatement.setInt(1, jobId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Applicant applicant = new Applicant();
                applicant.setId(resultSet.getInt("id"));
                applicant.setJobId(resultSet.getInt("job_id"));
                applicant.setStudentId(resultSet.getInt("student_id"));
                applicants.add(applicant);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return applicants;
    }

    @Override
    public List<Applicant> getAllApplicationsByStudent(int studentId) {
        List<Applicant> applications = new ArrayList<>();
        try (Connection connection = DBConnectionUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT * FROM applicants WHERE student_id = ?")) {
            preparedStatement.setInt(1, studentId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Applicant applicant = new Applicant();
                applicant.setId(resultSet.getInt("id"));
                applicant.setJobId(resultSet.getInt("job_id"));
                applicant.setStudentId(resultSet.getInt("student_id"));
                applications.add(applicant);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return applications;
    }

    @Override
    public boolean hasStudentApplied(int studentId, int jobId) {
        try (Connection connection = DBConnectionUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT COUNT(*) FROM applicants WHERE student_id = ? AND job_id = ?")) {
            preparedStatement.setInt(1, studentId);
            preparedStatement.setInt(2, jobId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public int getNumberOfApplicantsForJob(int jobId) {
        try (Connection connection = DBConnectionUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT COUNT(*) FROM applicants WHERE job_id = ?")) {
            preparedStatement.setInt(1, jobId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public boolean deleteApplicant(int applicantId) {
        try (Connection connection = DBConnectionUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "DELETE FROM applicants WHERE id = ?")) {
            preparedStatement.setInt(1, applicantId);
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

   @Override
    public Applicant getApplicantByJobAndStudent(int jobId, int id) {
    Applicant applicant = null;
    try (Connection connection = DBConnectionUtil.getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM applicants WHERE job_id = ? AND student_id = ?")) {
        preparedStatement.setInt(1, jobId);
        preparedStatement.setInt(2, id);
        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            if (resultSet.next()) {
                applicant = new Applicant();
                applicant.setId(resultSet.getInt("id"));
                applicant.setJobId(resultSet.getInt("job_id"));
                applicant.setStudentId(resultSet.getInt("student_id"));
                //applicant.setStatus(resultSet.getString("status"));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return applicant;
}


    @Override
    public boolean applyForJob(Applicant applicant) {
        boolean applied = false;
        try (Connection connection = DBConnectionUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO applicants (job_id, student_id, status) VALUES (?, ?, ?)")) {
            preparedStatement.setInt(1, applicant.getJobId());
            preparedStatement.setInt(2, applicant.getStudentId());
            //preparedStatement.setString(3, applicant.getStatus());
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                applied = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return applied;
    }

    @Override
public List<Applicant> getApplicantsByJobId(int id) {
    List<Applicant> applicants = new ArrayList<>();
    try (Connection connection = DBConnectionUtil.getConnection();
         PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM applicants WHERE job_id = ?")) {
        preparedStatement.setInt(1, id);
        try (ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                Applicant applicant = new Applicant();
                applicant.setId(resultSet.getInt("id"));
                applicant.setJobId(resultSet.getInt("job_id"));
                applicant.setStudentId(resultSet.getInt("student_id"));
                //applicant.setStatus(resultSet.getString("status"));
                applicants.add(applicant);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return applicants;
}

    @Override
    public boolean registerApplicant(Applicant applicant) {
        boolean registered = false;
        try (Connection connection = DBConnectionUtil.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO applicants (job_id, student_id, status) VALUES (?, ?, ?)")) {
            preparedStatement.setInt(1, applicant.getJobId());
            preparedStatement.setInt(2, applicant.getStudentId());
            preparedStatement.setString(3, applicant.getStatus());
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                registered = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return registered;
    }

    @Override
    public List<Applicant> getApplicantsByStudentId(int id) {
        List<Applicant> applicants = new ArrayList<>();
        try (Connection connection = DBConnectionUtil.getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM applicants WHERE student_id = ?")) {
            preparedStatement.setInt(1, id);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    Applicant applicant = new Applicant();
                    applicant.setId(resultSet.getInt("id"));
                    applicant.setJobId(resultSet.getInt("job_id"));
                    applicant.setStudentId(resultSet.getInt("student_id"));
                    applicant.setStatus(resultSet.getString("status"));
                    applicants.add(applicant);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return applicants;
    }

}
