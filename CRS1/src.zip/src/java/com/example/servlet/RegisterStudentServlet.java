/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Harikrishna
 */
package com.example.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.dao.StudentDAO;
import com.example.dao.StudentDAOImpl;
import com.example.model.Student;

@WebServlet("/registerStudent")
public class RegisterStudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private StudentDAO studentDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        studentDAO = new StudentDAOImpl();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        Student student = new Student();
        student.setName(name);
        student.setEmail(email);
        student.setPassword(password);

        boolean isRegistered = studentDAO.registerStudent(student);

        if (isRegistered) {
            request.setAttribute("message", "Successfully registered as a student!");
        } else {
            request.setAttribute("message", "Failed to register as a student!");
        }
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }
}
